/* testeSinistroTerceiro.cpp */
/* neste arquivo são testadas as classes:
   - Sinistro
   - GerenciarSinistro
   - Terceiro
   - CRUDTerceiro
   - PesssoaFisica */
/* g++ Data.h Data.cpp GerenciarSinistro.h GerenciarSinistro.cpp Sinistro.h Sinistro.cpp Terceiro.h Terceiro.cpp CRUDTerceiro.h CRUDTerceiro.cpp PessoaFisica.h testeSinistroTerceiro.cpp -o teste */

#include "GerenciarSinistro.h"
#include "Sinistro.h"
#include "Terceiro.h"
#include "CRUDTerceiro.h"
#include "PessoaFisica.h"
#include "BO.h"
#include "Data.h"

#include <iostream>

using namespace std;

int main ()
{
	GerenciarSinistro gs;
	CRUDTerceiro crudt;
	Data date, date2;
	Terceiro *terc;
	BO b;

	date.inserirData(8, 5, 1993);
	date2.inserirData(27, 6, 2013);

	crudt.criarTerceiro(20, "Giulianno", "9151-0021", "Jardim Itapuã", "Secured", "404.771.108-00");

	terc = crudt.getTerceiro();

	gs.criarSinistro(222, date2, "City of Evil", terc, 5, 666, date, "roubo e furto");

	gs.imprimirDadosSinistro();

	crudt.imprimirDadosTerceiro();

	return 0;
}