/* testeOrcamentoGerOrcam.cpp */
/* neste arquivo são testadas as classes 
   - Orcamento
   - GerenciarOrcamento */
/* g++ GerenciarOrcamento.cpp GerenciarOrcamento.h Orcamento.cpp Orcamento.h testeOrcamentoGerOrcam.cpp -o teste */

#include "GerenciarOrcamento.h"
#include "Orcamento.h"

#include <iostream>

using namespace std;

int main ()
{
	GerenciarOrcamento go;

	go.inserirOrcamento("Econômico", 15000.35);

	go.imprimirDadosOrcamento();

	cout << "Valor total: " << go.getValorTotal() << endl;
	cout << endl;

	go.inserirOrcamento("VIP", 135000);

	go.imprimirDadosOrcamento();

	cout << "Valor total: " << go.getValorTotal() << endl;

	return 0;
}