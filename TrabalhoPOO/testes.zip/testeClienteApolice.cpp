/* testeClienteApolice.cpp */
/* neste arquivo são testadas as classes:
   - Sinistro
   - GerenciarSinistro
   - Terceiro
   - CRUDTerceiro
   - PesssoaFisica */
/* g++ Data.h Data.cpp GerenciarSinistro.h GerenciarSinistro.cpp Sinistro.h Sinistro.cpp Terceiro.h Terceiro.cpp CRUDTerceiro.h CRUDTerceiro.cpp PessoaFisica.h GerenciarSegudos.cpp GerenciarSegudos.h Cliente.cpp Cliente.h Apolice.cpp Apolice.h testeClienteApolice.cpp-o teste */


#include "GerenciarSegurados.h"
#include "Cliente"
#include "GerenciarSinistro.h"
#include "Sinistro.h"
#include "CRUDTerceiro.h"
#include "Terceiro.h"
#include "PessoaFisica.h"
#include "BO.h"
#include "Data.h"
#include "Apolice.h"
#include "GerenciarOrcamento.h"
#include "Orcamento.h"

#include <iostream>

using namespace std;

int main ()
{
	GerenciarSegurados segurados;
	GerenciarOrcamento go;
	GerenciarSinistro gs;
	GerenciarVeiculos gv;
	CRUDTerceiro crudt;
	Data date, date2, date3;
	Terceiro *terc;
	Cliente *c;
	BO b;
	Sinistro *snt;
	Apolice apolice;
	Veiculo *veiculo;
	Orcamento *orcamento;

	cout << "Teste Cliente e Apólice" << endl;

	date.inserirData(8, 5, 1993);																	 /* cria um objeto do tipo DATA */
	date2.inserirData(27, 6, 2013);																	 /* cria um objeto do tipo DATA */
	date3.inserirData(12, 7, 2013);																	 /* cria um objeto do tipo DATA */

	crudt.criarTerceiro(20, "Giulianno", "9151-0021", "Jardim Itapuã", "Secured", "404.771.108-00"); /* cria um objeto do tipo TERCEIRO */

	terc = crudt.getTerceiro();                                                                      /* faz terc apontar para o objeto criado */

	gs.criarSinistro(222, date2, "City of Evil", terc, 5, 666, date, "roubo e furto");				 /* cria um objeto do tipo SINISTRO */

	snt = gs.getSinistro();																			 /* faz snt apontar para o objeto criado */

	go.inserirOrcamento("Econômico", 15000.35);														 /* cria um objeto do tipo ORCAMENTO */

	orcamento = go.getOrcamento();																	 /* faz orcamento apontar para o objeto criado */

	gv.inserirVeiculo("DFW-3900", 2013, "404.771.108-00", 1, 2);									 /* cria um objeto do tipo VEICULO */

	veiculo = gv.getVeiculo();																		 /* faz veiculo apontar para o objeto criado */

	apolice.criarApolice(121, 1, date3, );






	gs.imprimirDadosSinistro();

	crudt.imprimirDadosTerceiro();

	return 0;
}