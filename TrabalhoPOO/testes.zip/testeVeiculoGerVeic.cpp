/* testeVeiculoGerVeic.cpp */
/* neste arquivo são testadas as classes 
   - Veiculo
   - GerenciarVeiculos */
/* g++ GerenciarVeiculos.cpp GerenciarVeiculos.h Veiculo.cpp Veiculo.h testeVeiculoGerVeic.cpp -o teste */

#include "GerenciarVeiculos.h"
#include "Veiculo.h"

#include <iostream>

using namespace std;

int main ()
{
	GerenciarVeiculos gv;

	gv.inserirVeiculo("DFW-3900", 2013, "404.771.108-00", 1, 2);

	gv.imprimirDadosVeiculo();

	return 0;
}