/* testeBOData.cpp */
/* neste arquivo são testadas as classes 
   - BO
   - Data */
/* g++ BO.cpp BO.h Data.cpp Data.h testeBOData.cpp -o teste */

#include "BO.h"
#include "Data.h"


#include <iostream>

using namespace std;

int main ()
{
	BO bo;
	Data date;

	date.inserirData(8, 5, 1993);

	bo.criarBO(666, date, "roubo e furto");

	bo.imprimirDadosBO();

	return 0;
}